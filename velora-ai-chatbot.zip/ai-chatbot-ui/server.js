const express=require('express');const path=require('path');const app=express();app.use(express.json());app.use(express.static(__dirname));
app.post('/api/chat',async(req,res)=>{const message=String(req.body?.message||'').trim();if(!message)return res.status(400).json({error:'Message required'});
  // Replace this small backend with your AI provider call. Keep the API key server-side.
  const reply=`I’m Velora, your AI assistant. You asked: “${message}”\n\nThis demo backend is intentionally small and working. Connect your preferred AI API inside /api/chat to turn this into a full AI assistant.`;
  res.json({reply});
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'index.html')));
app.listen(process.env.PORT||3000,()=>console.log('Velora running on http://localhost:3000'));