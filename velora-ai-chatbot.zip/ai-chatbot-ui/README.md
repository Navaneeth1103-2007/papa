# Velora — aesthetic AI chatbot UI

## Run
1. Install Node.js.
2. Open a terminal in this folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

The UI is intentionally much richer than the backend. The backend has one small `/api/chat` endpoint and keeps the architecture easy to replace with a real AI provider.

To connect an AI API, edit `server.js` and make the provider request from `/api/chat`. Keep the API key on the server; never put it in `app.js`.
